/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Censo;

/**
 *
 * @author sebastianrb04
 */
public class Departamento {

    //Atributos
    String nombre;
    int poblacion;
    int cantHombres;
    double edadProm;
    double ingresoProm;
    int temperatura;
    int cantMujeres;

    //Constructor
    public Departamento(String nombre,int poblacion,int cantHombres,double edadProm,double ingresoProm,int temperatura) {
        this.nombre = nombre;
        this.cantHombres = cantHombres;
        this.poblacion = poblacion;
        this.edadProm = edadProm;
        this.ingresoProm = ingresoProm;
        this.temperatura = temperatura;

    }

    //Getters
    public String getNombre() {
        return nombre;
    }

    public int getPoblacion() {
        return poblacion;
    }

    public int getHombres() {
        return cantHombres;
    }
     public int getMujeres() {
         return cantMujeres; 

     }
    public double getEdadProm(){
        return edadProm;
    }
    public double getIngresoProm(){
        return ingresoProm;
    }

    //Setters
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPoblacion(int poblacion) {
        this.poblacion = poblacion;
    }

    public void setCantHombres(int cantHombres) {
        this.cantHombres = cantHombres;
    }

    //Calcular mujeres
    public int cantidadMujeres() {
        int cantidadMujeres;
        cantidadMujeres = this.poblacion - this.cantHombres;
        this.cantMujeres = cantidadMujeres;
        return cantidadMujeres;
    }

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder("Datos del Departamento:\n");
        s.append("Nombre: ").append(this.nombre).append("\n");
        s.append("Población: ").append(this.poblacion).append("\n");
        s.append("Cantidad de Hombres: ").append(this.cantHombres).append("\n");
        s.append("Cantidad de Mujeres: ").append(this.cantidadMujeres()).append("\n");
        s.append("Edad Promedio: ").append(this.edadProm).append("\n");
        s.append("Ingreso Promedio: ").append(this.ingresoProm).append("\n");
        s.append("Temperatura: ").append(this.temperatura).append(" °C\n");
        return s.toString();
    }

}
