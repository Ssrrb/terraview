/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Censo;

import Censo.Departamento;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

/**
 *
 * @author sebastianrb04
 */
public class Censo {

    int totalDpt = 17;
    // Datos correspondientes a cada departamento en el CSV
    Departamento[] departamentos = new Departamento[17];

    //Constructor 
    public Censo() {
        this.departamentos = departamentos;
    }

    //Cargar los datos
    public void cargarDatos() throws FileNotFoundException {
        File f = new File("censo.csv");
        try {
            BufferedReader archivo = new BufferedReader(new FileReader(f));
            String registro = archivo.readLine();
            int i = 0;
            while (registro != null) {
                registro = registro.trim();
                String campos[] = registro.split(";");
                departamentos[i] = new Departamento(
                        campos[0],
                        Integer.parseInt(campos[1]),
                        Integer.parseInt(campos[2]),
                        Double.parseDouble(campos[3]),
                        Double.parseDouble(campos[4]),
                        Integer.parseInt(campos[5]));;
                i++;
                registro = archivo.readLine();
            }
        } catch (NumberFormatException e) {
            System.out.println("Error de formato numérico en la línea " + (i + 1) + ": " + e.getMessage());
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Faltan campos en la línea " + (i + 1) + ": " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error inesperado al procesar la línea " + (i + 1) + ": " + e.getMessage());
        }
        archivo.close();

    }

//Calcular la cantidad total de hombres
    public int totalHombres() {
        int totalH = 0;
        for (int i = 0; totalDpt < i; i++) {
            totalH += departamentos[i].getHombres();
        }
        return totalH;
    }

    //Cantidad total de mujeres.
    public int totalMujeres() {
        int totalM = 0;
        for (int i = 0; totalDpt < i; i++) {
            totalM += departamentos[i].getMujeres();
        }
        return totalM;
    }

    // Edad promedio de la población.
    public double edadPromedio() {
        double edadProm = 0;
        for (Departamento d : departamentos) {
            edadProm += d.getEdadProm();
        }
        return edadProm / 17;
    }

    // Ingreso promedio de todos los departamentos.
    public double ingresoPromedio() {
        double totalIn = 0;
        for (Departamento d : departamentos) {
            totalIn += d.getIngresoProm();
        }
        return totalIn / 17;
    }

}
